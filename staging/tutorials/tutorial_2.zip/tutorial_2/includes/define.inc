# SPDX-FileCopyrightText: 2026 Fonden Mærsk Mc-Kinney Møller Center for Zero Carbon Shipping
# SPDX-License-Identifier: CC-BY-4.0

# This Tutorial 2 define.inc file is an edited copy of the define file from Tutorial 1. 
# Lengthy comments from tutorial 1 were removed to give you a better overview.

# The model definition and the Start of the timeline are the same as in tutorial 1.
ModelDefinition {
	StartDate = "01/01/2025"
}


# A) Definition of the fleets and nodes related to all vessels
# Ai) Container fleet
# Below is the definition of the fleet from tutorial 1. 
Fleet "fleet" {
	Vessels = [Vessel("vessel_ice_oil")]
	FuelSensitivity = 0.5
	VariantSensitivity = 0.5
	InitialVessels = 100
}

# Aii) Bulk carrier fleet
# Paste the copy of the Fleet node "container_fleet" below, and make edits as
# described in the tutorial:


# Aiii) Decision sensitivities are now set directly on the fleet above
# (FuelSensitivity, VariantSensitivity, TechnologySensitivity).


# B) DEFINITION OF ALL FOUR VESSELS
# Bi) Definition of fuel oil vessel
# Change the the value assigned to the attribute Tanks below.

Vessel "vessel_ice_oil" {
	PropulsionConverter = Converter("propulsion_ice_oil")
	ElectricalConverter = Converter("electrical_ice_oil")
	HeatConverter = Converter("heat_boiler_oil")
	Route = Route("route")
	NominalCapacity = 8000
	Tanks = [Tank("main_oil")]
	PropulsionLoad = 10
}

Converter "propulsion_ice_oil" {
	PowerCapacity = 50
	MainFuelTypes = OIL
	Efficiency = 0.5
}

Converter "electrical_ice_oil" {
	PowerCapacity = 10
	MainFuelTypes = OIL
	Efficiency = 0.5
}

Converter "heat_boiler_oil" {
	PowerCapacity = 5
	MainFuelTypes = OIL
	Efficiency = 0.5
}


# Bii) DEFINITION OF METHANE VESSEL
# This definition has the same structure as the definition of the fuel oil vessel, but has
# different assigned values.
#
# Define Vessel "container_ice_methane", Converter "propulsion_ice_methane" and
# Converter "electrical_ice_methane". The vessel reuses Converter "heat_boiler_oil".
#
# Paste the Vessel and the two Converter nodes from section Bi) below.




# Biii) DEFINITION OF METHANOL VESSEL
#
# Define Vessel "bulk_ice_methanol", Converter "propulsion_ice_methanol" and
# Converter "electrical_ice_methanol". The vessel reuses Converter "heat_boiler_oil".
#
# Paste the Vessel and the two Converter nodes from section Bi) below.




# Biv) DEFINITION OF AMMONIA VESSEL
#
# Define Vessel "bulk_ice_ammonia", Converter "propulsion_ice_ammonia" and
# Converter "electrical_ice_ammonia". The vessel reuses Converter "heat_boiler_oil".
#
# Paste the Vessel and the two Converter nodes from section Bi) below.



# C) GENERAL SPECIFICATIONS FOR VESSELS

# Define the vessel route below (same as in tutorial 1). 
Route "route" {
	RouteType = TRAMP
	Ports = [Port("port")]
	TimeAtSea = 0.75
	set_distance_share("*", "*", 1)
	set_speed("*", "*", 10)
}


# Define the vessel tank below.
Tank "main_oil" {
	FuelTypes = OIL
	Volume = 9000
}

# Ci) DEFINITION OF PILOT TANK
# Define Tank "pilot_oil".
# Paste the node Tank "main_oil" from section C) below.


# Cii) DEFINITION OF METHANE TANK
# Define Tank "main_methane".
# Paste the node Tank "main_oil" from section C) below.



# Ciii) DEFINITION OF METHANOL TANK
# Define Tank "main_methanol".
# Paste the node Tank "main_oil" from section C) below.



# Civ) DEFINITION OF AMMONIA TANK
# Define Tank "main_ammonia".
# Paste the node Tank "main_oil" from section C) below.



# D) DEFINITION OF THE PORT AND THE REGION
# Definition of the node "port" and BunkeringLogistics from tutorial 1 below:
Port "port" {
	set_fuel_price("heavy_fuel_oil", 250)
	set_fuel_wtt("heavy_fuel_oil", "carbon_dioxide", 0.62)
}


# Definition of the node "Region" 

	# e-methane
	

	# Bio-methanol
	

	# Blue ammonia
	


# E) DEFINITION OF ALL FOUR FUELS
# Ei) Definition of heavy_fuel_oil

# Definition of "heavy_fuel_oil" (same as Tutorial 1).
Fuel "heavy_fuel_oil" {
	FuelType = OIL
	LiquidMarket = TRUE
	LowerHeatingValue = 41.2
	MassDensity = 0.9

	set_ttw("carbon_dioxide", 3.114)
	set_ttw("methane", 0.00005)
	set_ttw("nitrous_oxide", 0.00018)
}

Emission "carbon_dioxide" {
	Gwp = 1
}

Emission "methane" {
	Gwp = 25
}

Emission "nitrous_oxide" {
	Gwp = 273
}


# Eii) Definition of electro-methane
# Define the methane production plant Plant "plant_methane_electro"


# define fuel and processes
# Define Fuel "methane_electro"


# Define Process "methane_liquefaction_electro"



# Define Process "methane_synthesis_electro"



# Define Feedstocks



# Eiii) Definition of bio-methanol
# Paste the nodes "plant_methane_electro", Fuel "methane_electro", "methane_synthesis_electro", Feedstock "demineralized_water" and Feedstock "carbon_dioxide_biogenic"  from section Bi) below:



# Eiv) Definition of blue ammonia
# Paste the nodes "plant_methane_electro", Fuel "methane_electro", "methane_synthesis_electro", Feedstock "demineralized_water" and Feedstock "carbon_dioxide_biogenic"  from section Bii) below:


# Ev) Definition of electricity source
# Paste the Source nodes "renewable" and Source "grid"

# F) Definition of Fuel Producer node
# Define the Producer "engineering_procyurement_construction_global"


# Set the producer decision sensitivities (FuelSensitivity, VariantSensitivity)



# END OF NAV FILE